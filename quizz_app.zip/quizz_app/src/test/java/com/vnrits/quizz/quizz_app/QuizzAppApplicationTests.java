package com.vnrits.quizz.quizz_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuizzAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
